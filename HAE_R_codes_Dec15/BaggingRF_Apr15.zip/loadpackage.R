# load several packages
library(ggplot2)
library(ROCR)
library(PRROC)
# library(FSelector)
library(randomForest)
library(caret)
library(e1071)
library(reshape2)
library(sqldf)
library(glmnet)
library(caTools)
library(gbm)
# library(xlsx)
library(dplyr)
library(snowfall)
library(plyr)





